# Metro Dash 3D Android APK project

This Android wrapper packages the Metro Dash 3D Ultimate Realism Edition HTML game into a landscape, immersive Android app using Android WebView. Three.js is loaded from jsDelivr with an unpkg fallback, so the first launch and gameplay need an internet connection. The Android wrapper enables hardware-accelerated WebView rendering and logs JavaScript console errors for diagnosis. If the 3D engine or WebGL cannot start, the game now displays a clear error screen instead of silently showing a blank scene.

## Build an APK using your phone and GitHub

1. Download and extract this ZIP.
2. In GitHub, create a new repository named `metro-dash-android` (Public is simplest for a first build).
3. Upload the **contents** of this folder to the repository root, including the hidden `.github` folder. If using GitHub's browser upload, ensure `.github/workflows/build-apk.yml` is included; if the mobile website hides hidden folders, use GitHub's web editor to create that workflow file.
4. Open the repository's **Actions** tab and select **Build Metro Dash APK**. If prompted, enable Actions.
5. Open the workflow run after it finishes successfully. Under **Artifacts**, tap **Metro-Dash-3D-APK** to download the ZIP containing `app-debug.apk`.
6. Extract it on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser or file manager. Only install APKs you built from your own repository.

## Build locally

Requires JDK 17, Android SDK Platform 35, and Gradle 8.9. Run `gradle assembleDebug`; the APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- Package ID: `com.metrodash.game`
- Orientation: landscape
- Minimum Android version: Android 6.0 (API 23)
- This project builds a debug APK, suitable for testing. A signed release APK/AAB should be created before publishing to Google Play.


## If 3D does not appear

- Make sure the phone is online when opening the game.
- Update **Android System WebView** and **Google Chrome** in the Play Store.
- Rebuild the APK after uploading these updated project files.
- If the app displays a 3D startup error, try another network; some networks block public JavaScript CDNs.
