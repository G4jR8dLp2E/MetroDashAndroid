# No custom shrinking rules required for the debug build.
